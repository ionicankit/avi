import { Component, OnInit } from '@angular/core';

import * as $ from 'jquery';

@Component({
  selector: 'app-multicolumnslider',
  templateUrl: './multicolumnslider.component.html',
  styleUrls: ['./multicolumnslider.component.css']
})
export class MulticolumnsliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
